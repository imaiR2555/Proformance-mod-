# Proformance (Fabric, Minecraft 1.21.10)

Client-side FPS mod. On the first world you join it lowers the video settings
that cost the most FPS (render/simulation distance, entity distance, particles,
clouds, biome blend, graphics mode, smooth lighting, entity shadows).
It never raises a setting you already set lower yourself.

Modes (config/proformance.properties):
- AUTO      picks LOW_END on weak devices (4 or fewer cores, or 2 GB or less max memory), else BALANCED
- BALANCED  good FPS boost, still looks fine
- LOW_END   maximum FPS for weak devices
- OFF       does nothing

Set applyEveryJoin=true to re-apply the preset every time you join a world.

## Build the jar

On a computer with Java 21 and Gradle 8.14+:

    gradle build

The jar is build/libs/proformance-1.0.0.jar

No computer? Put these files in a GitHub repository (keep the folder layout).
The "build" workflow runs on every push; open the Actions tab, open the latest
run, and download the proformance-jar artifact.

## Install

Copy the jar into the mods folder of your Fabric 1.21.10 profile (Mojo Launcher
included) together with Fabric API 0.138.3+1.21.10.
