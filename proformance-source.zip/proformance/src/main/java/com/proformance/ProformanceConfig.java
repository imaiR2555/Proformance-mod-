package com.proformance;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

/** Tiny config stored in config/proformance.properties. */
public final class ProformanceConfig {
    public enum Mode { AUTO, BALANCED, LOW_END, OFF }

    public Mode mode = Mode.AUTO;
    public boolean applyEveryJoin = false;
    private boolean applied = false;

    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("proformance.properties");

    public static ProformanceConfig load() {
        ProformanceConfig cfg = new ProformanceConfig();
        Properties props = new Properties();

        if (Files.exists(cfg.file)) {
            try (Reader reader = Files.newBufferedReader(cfg.file)) {
                props.load(reader);
            } catch (IOException e) {
                Proformance.LOGGER.warn("Could not read config, using defaults", e);
            }
        }

        String modeName = props.getProperty("mode", "AUTO").trim().toUpperCase(Locale.ROOT);
        try {
            cfg.mode = Mode.valueOf(modeName);
        } catch (IllegalArgumentException e) {
            cfg.mode = Mode.AUTO;
        }
        cfg.applyEveryJoin = Boolean.parseBoolean(props.getProperty("applyEveryJoin", "false").trim());
        cfg.applied = Boolean.parseBoolean(props.getProperty("applied", "false").trim());

        cfg.save();
        return cfg;
    }

    public boolean shouldApply() {
        return mode != Mode.OFF && (applyEveryJoin || !applied);
    }

    public void markApplied() {
        if (!applied) {
            applied = true;
            save();
        }
    }

    public void save() {
        Properties props = new Properties();
        props.setProperty("mode", mode.name());
        props.setProperty("applyEveryJoin", Boolean.toString(applyEveryJoin));
        props.setProperty("applied", Boolean.toString(applied));

        try {
            Files.createDirectories(file.getParent());
            try (Writer writer = Files.newBufferedWriter(file)) {
                props.store(writer,
                        "Proformance config\n"
                                + "mode: AUTO, BALANCED, LOW_END or OFF\n"
                                + "applyEveryJoin: true = re-apply the preset every time you join a world\n"
                                + "applied: set automatically after the first run (set to false to apply again)");
            }
        } catch (IOException e) {
            Proformance.LOGGER.warn("Could not save config", e);
        }
    }
}
