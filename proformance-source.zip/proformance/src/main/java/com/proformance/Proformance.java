package com.proformance;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Proformance: lowers the video settings that cost the most FPS.
 * It never raises a setting you already set lower yourself.
 */
public class Proformance implements ClientModInitializer {
    public static final String MOD_ID = "proformance";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private record Preset(int renderDistance, int simulationDistance, double entityScale,
                          ParticleStatus particles, CloudStatus clouds, int biomeBlend,
                          boolean smoothLighting) {}

    // Good FPS boost, still looks fine.
    private static final Preset BALANCED =
            new Preset(10, 8, 0.75, ParticleStatus.DECREASED, CloudStatus.FAST, 1, true);

    // Maximum FPS for weak devices.
    private static final Preset LOW_END =
            new Preset(6, 5, 0.5, ParticleStatus.MINIMAL, CloudStatus.OFF, 0, false);

    @Override
    public void onInitializeClient() {
        ProformanceConfig config = ProformanceConfig.load();

        // Apply once a world is joined, so the renderer is fully ready.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) ->
                client.execute(() -> apply(client, config)));

        LOGGER.info("Proformance loaded (mode: {})", config.mode);
    }

    private static ProformanceConfig.Mode detectMode() {
        int cores = Runtime.getRuntime().availableProcessors();
        long maxHeapMb = Runtime.getRuntime().maxMemory() / (1024L * 1024L);
        boolean weak = cores <= 4 || maxHeapMb <= 2048;
        return weak ? ProformanceConfig.Mode.LOW_END : ProformanceConfig.Mode.BALANCED;
    }

    private static void apply(Minecraft mc, ProformanceConfig config) {
        if (!config.shouldApply()) {
            return;
        }

        ProformanceConfig.Mode mode = config.mode;
        if (mode == ProformanceConfig.Mode.AUTO) {
            mode = detectMode();
        }
        final Preset p = (mode == ProformanceConfig.Mode.LOW_END) ? LOW_END : BALANCED;
        final Options o = mc.options;

        safely("render distance", () ->
                o.renderDistance().set(Math.min(o.renderDistance().get(), p.renderDistance())));

        safely("simulation distance", () ->
                o.simulationDistance().set(Math.min(o.simulationDistance().get(), p.simulationDistance())));

        safely("entity distance", () ->
                o.entityDistanceScaling().set(Math.min(o.entityDistanceScaling().get(), p.entityScale())));

        safely("biome blend", () ->
                o.biomeBlendRadius().set(Math.min(o.biomeBlendRadius().get(), p.biomeBlend())));

        safely("particles", () -> {
            if (p.particles().ordinal() > o.particles().get().ordinal()) {
                o.particles().set(p.particles());
            }
        });

        safely("clouds", () -> {
            if (p.clouds().ordinal() < o.cloudStatus().get().ordinal()) {
                o.cloudStatus().set(p.clouds());
            }
        });

        safely("graphics", () -> {
            if (o.graphicsMode().get() != GraphicsStatus.FAST) {
                o.graphicsMode().set(GraphicsStatus.FAST);
            }
        });

        safely("smooth lighting", () -> {
            if (!p.smoothLighting()) {
                o.ambientOcclusion().set(false);
            }
        });

        safely("entity shadows", () -> o.entityShadows().set(false));

        safely("save options", o::save);

        config.markApplied();
        LOGGER.info("Proformance applied the {} preset", mode);
    }

    private static void safely(String what, Runnable action) {
        try {
            action.run();
        } catch (Throwable t) {
            LOGGER.warn("Proformance could not change: {}", what, t);
        }
    }
}
